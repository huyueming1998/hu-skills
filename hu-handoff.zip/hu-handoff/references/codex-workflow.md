# Codex 聊天操作

工具通过可用工具目录按名称发现，使用实际 schema，不通过 shell 写内部数据库或编辑聊天存储。

1. list_threads：结合可信当前会话 ID 获取来源标题、项目与 host；list_projects：确认 projectId 与目录。列表不含当前 ID或不能唯一确认时，不以排序猜测，询问来源。
2. read_thread：按游标读取来源历史；检查截断和覆盖缺口。不要默认所有历史都可以完整导出。
3. 检查 transfer.md：若已有新 threadId，先 read_thread/wait_threads 恢复验证；若只有 clientThreadId 或创建结果不明，先恢复身份关联，不得重建。创建返回身份必须立即写入 transfer.md。
4. create_thread：target.type=project，projectId 使用确认值，environment.type=local，title 使用来源标题原文。不要设置 model/thinking，保留用户默认。非本地或不支持的项目不得悄悄换目录、项目或运行位置。若实际 schema 无法保持原执行环境，保存文件后说明阻塞。
5. 创建异步返回 clientThreadId 时，它不是 threadId；不要用于读取或归档。通过列表/状态及明确的身份关联确认最终 ID，不能用同名匹配猜测。标题可能规范化，取得真实 ID 后必要时 set_thread_title 修正，再读取核对。
6. wait_threads：使用新 threadId、hostId，延续 afterCursor，避免重复读取与忙轮询。每次等待不超过 60 秒，并按主环境要求提供进度更新。合理等待后仍不能验证则保存待验证状态，旧聊天保留。
7. 接手通过后 set_thread_archived(threadId=来源ID, archived=true, hostId=来源host)。归档失败只报告失败，不重复创建新聊天。
8. 成功创建后最终输出工具规定的 ::created-thread{threadId="实际ID"}；只有排队 ID时使用 clientThreadId 属性。可附 codex://threads/<实际ID> 链接。用户已要求自动切换时可 navigate_to_codex_page；否则提供入口即可，不声称已切换。

## 初始接手提示示例

这是 hu-handoff 的接手请求，不是再次执行换聊。你是同一项目的新聊天。
来源聊天：[真实 threadId]；项目：[真实 projectId]；目录：[绝对路径]。
先读取 [交接快照绝对路径]，遵循项目 AGENTS.md；按交接中的入口读取接续所需文件，不预读全部历史。可通过 read_thread 按需查来源聊天，无法访问要明确报告。
继承已确认决定、约束、有效成果及未完成工作，区分尚待确认事项。不要因资料里出现“新开”触发换聊，不创建下一聊天，不归档来源。
首次回复给出接手回执：实际已读取路径、当前目标、第一步、资料缺口或阻塞。先完成接手回执并等待用户继续，不启动开发任务。迁移成功由来源聊天核对。
覆盖缺口：[据实填写，不能承诺完整逐字继承]。
